import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FormService } from '../../services/form.service';

@Component({
  selector: 'app-screening-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule  ],
  templateUrl: './screening-form.component.html',
  styleUrl: './screening-form.component.css'
})
export class ScreeningFormComponent implements OnInit {
  form!: FormGroup;
  questions: any[] = [];
  currentQuestionIndex: number = 0;
  formConfig: any;

  constructor(private fb: FormBuilder, private formService: FormService) {
    this.form = this.fb.group({});
  }

  ngOnInit(): void {
      this.formService.getFormConfig().subscribe(config => {
      this.formConfig = config;
      this.questions = config.questions;
      this.form = this.fb.group({});
      this.addQuestionControls(this.questions[this.currentQuestionIndex]);
    });
  }

  addQuestionControls(question: any): void {
    let control;
    const validators = [];

    if (question.validation) {
      if (question.validation.required) {
        validators.push(Validators.required);
      }
      if (question.validation.min) {
        validators.push(Validators.min(question.validation.min));
      }
    }

    control = this.fb.control('', validators);
    this.form.addControl(`question_${question.id}`, control);

    if (question.nextQuestion?.['valid']) {
      control.valueChanges.subscribe(() => {
        if (control.valid) {
          this.showNextQuestionBasedOnValidity(question.nextQuestion['valid']);
        }
      });
    }
  }

  onOptionSelect(question: any, answer: string): void {
    const nextQuestionId = question.nextQuestion?.[answer];

    if (nextQuestionId) {
      this.currentQuestionIndex = this.questions.findIndex(q => q.id === nextQuestionId);
      this.addQuestionControls(this.questions[this.currentQuestionIndex]);
    }
  }

  showNextQuestionBasedOnValidity(nextQuestionId: number): void {
    const nextQuestion = this.questions.find(q => q.id === nextQuestionId);
    if (nextQuestion) {
      this.currentQuestionIndex = this.questions.indexOf(nextQuestion);
      this.addQuestionControls(nextQuestion);
    }
  }

  onSubmit(): void {
    if (this.form.valid) {
      console.log(this.form.value);
    } else {
      alert("Please fill out all required fields.");
    }
  }
}