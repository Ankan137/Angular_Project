export const FORM_CONFIG = {
  "title": "Screen Candidate Form",
  "description": "This form screens the candidate for Angular Developer Role.",
    "questions": [
      {
        "id": 1,
        "type": "radio",
        "label": "Do you have any previous experience with Angular?",
        "options": ["Yes", "No"],
        "nextQuestion": {
          "Yes": 2,
          "No": null
        }
      },
      {
        "id": 2,
        "type": "text",
        "label": "How many years of experience do you have?",
        "placeholder": "Enter years of experience",
        "validation": {
          "required": true,
          "min": 1
        },
        "nextQuestion": {
          "valid": 3
        }
      },
      {
        "id": 3,
        "type": "textarea",
        "label": "What are the most complex projects you've worked on?",
        "placeholder": "Describe your project...",
        "validation": {
          "required": true
        }
      }
    ]
  }
  