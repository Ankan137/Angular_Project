import { Component } from '@angular/core';
import { ScreeningFormComponent } from './components/screening-form/screening-form.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [ScreeningFormComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'screen-candidate-form';
}
