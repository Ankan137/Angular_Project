import { Injectable } from "@angular/core";
import { Observable, of } from "rxjs";
import { FORM_CONFIG } from "../config/form.constants";


@Injectable({
  providedIn: 'root'
})
export class FormService {
  getFormConfig(): Observable<any> {
    return of(FORM_CONFIG);
  }
}